window.addEventListener("load", () =>{
    const preloader = document.querySelector(".containerPreload");
    preloader.classList.add('preload-finish');
});

